package com.infy.Demo_SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
